package com.paymentdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginregisterfromApplicationTests {

	@Test
	void contextLoads() {
	}

}
