package com.paymentdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginregisterfromApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginregisterfromApplication.class, args);
	}

}
